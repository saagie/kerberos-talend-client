package routines;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class MathInterpretor {

	private static final String NUMBER_GROUP = "([0-9\\\\.]+)";
	private static final String OPERATION_GROUP = "([<>=][=]{0,1})";
	// (number)(operation)(number)
	private static final String REGEX = NUMBER_GROUP + OPERATION_GROUP + NUMBER_GROUP;
	
	/*
	 * Evaluate an mathematical interval
	 * @param operation is the operation to evaluate, as "0<x<=10"
	 * @param identifier is the unknown parameter, as "x"
	 * @param value is the value to use to evaluate the operation
	 */
   public static boolean eval(String operation, String identifier, String value) {
	   
	   
	   if(operation == null || identifier == null || value == null) {
		   return false;
	   }
	   
	   if(operation.equals(identifier)) {
    		return true;
    	}
    	    	
    	Matcher m = Pattern.compile(REGEX).matcher(operation.replaceAll(identifier, value));
    	
    	if(m.matches() && m.groupCount() >= 3) {
    		BigDecimal left = new BigDecimal(m.group(1));
    		String operator = m.group(2);
    		BigDecimal right = new BigDecimal(m.group(3));
    		boolean out = false;
    		
    		if(operator != null) {
    			if(operator.contains("<")) {
    				out |= left.compareTo(right) < 0;
    			}
    			if(operator.contains(">")) {
    				out |= left.compareTo(right) > 0;
    			}
    			if(operator.contains("=")) {
    				out |= left.compareTo(right) == 0;
    			}
    		}
    		
    		return out;
    	} else {
        	String left = operation.substring(0, operation.indexOf(identifier) + identifier.length());
        	String right = operation.substring(operation.indexOf(identifier));

    		return eval(left, identifier, value) && eval(right, identifier, value);
    	}
    }
}
